
package lab4p1_juanponciano;

import java.util.Scanner;

public class Lab4P1_JuanPonciano {


    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        System.out.println("*****MENU*****");
        System.out.println("1. Inversión Especial");
        System.out.println("2. Balanza de Cadenas");
        System.out.println("3. Cifrado de Mensajes");
        int opcion = leer.nextInt();
        
        switch(opcion){
            case 1:{
                String cadena;
                System.out.println("Ingrese la cadena: ");
                leer.nextLine();
                cadena = leer.nextLine();
                String cadenainvertida = "";
                if(cadena.length() >= 5){
                    for (int i = 0; i < cadena.length();i++){
                        char caracter = cadena.charAt(i);
                        cadenainvertida = caracter + cadenainvertida;
                    }
                    System.out.println("Cadena Invertida: "+ cadenainvertida);
                }
                else{
                    System.out.println("La cadena debe tener al menos 5 caracteres");
                }
            }//fin del case 1
                break;
            case 2:{
                String cadena1;
                System.out.println("Ingrese la cadena 1: ");
                leer.nextLine();
                cadena1 = leer.nextLine();
                int cadena11 = 0;
                for (int i = 0; i < cadena1.length(); i++){
                    cadena11 = cadena11 +(int)cadena1.charAt(i);
                }
                
                String cadena2;
                System.out.println("Ingrese la cadena 2: ");
                cadena2 = leer.nextLine();
                int cadena22 = 0;
                for (int i = 0; i < cadena2.length(); i++){
                    cadena22 = cadena22 +(int)cadena2.charAt(i);
                }
                
                String cadena3 ;
                System.out.println("Ingrese la cadena 3: ");
                cadena3 = leer.nextLine();
                int cadena33 = 0;
                for (int i = 0; i < cadena3.length(); i++){
                    cadena33 = cadena33 +(int)cadena3.charAt(i);
                }
                
                System.out.println("Peso cadena 1: "+ cadena11);
                System.out.println("Peso cadena 2: "+ cadena22);
                System.out.println("Peso cadena 3: "+ cadena33);
                
                if (cadena11 > cadena22 && cadena11 > cadena22){
                System.out.println("La cadena 1 es más pesada");
                }
                if (cadena22 > cadena11 && cadena22 > cadena33){
                    System.out.println("La cadena 2 es más pesada");
                } 
                if (cadena33 > cadena11 && cadena33 > cadena22){
                    System.out.println("La cadena 3 es más pesada");
                } else{
                    System.out.println("Todas las cadenas tienen el mismo peso");
                }
            }//fin case 2
            
            
            
                break;
            case 3:{
                String cifrar;
                System.out.println("Ingrese el mensaje que desea cifrar: ");
                leer.nextLine();
                cifrar = leer.nextLine();
                String cifrado = "";
                if(cifrar.length() >0){
                    for (int i = 0; i < cifrar.length(); i++){
                    int cifra2 =  (int)cifrar.charAt(i)+ 2;
                    cifrado = cifrado+(char) cifra2;
                        
                    }
                   System.out.println(cifrado);
                } else {
                    System.out.println("La cadena no puede ser nula");
                }
                
            }//fin case 3
                break;
                
        }//fin del switch
        
    }//fin del main
    
}// fin de la clase
